package com.example.prog11;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private Button btnAlpha, btnRotate, btnScale, btnTranslate, btnCombine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        textView = findViewById(R.id.textView);
        btnAlpha = findViewById(R.id.btnAlpha);
        btnRotate = findViewById(R.id.btnRotate);
        btnScale = findViewById(R.id.btnScale);
        btnTranslate = findViewById(R.id.btnTranslate);
        btnCombine = findViewById(R.id.btnCombine);

        // Set click listeners
        btnAlpha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyAlphaAnimation();
            }
        });

        btnRotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyRotateAnimation();
            }
        });

        btnScale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyScaleAnimation();
            }
        });

        btnTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyTranslateAnimation();
            }
        });

        btnCombine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyCombinedAnimation();
            }
        });
    }

    // Method 1: Alpha Animation (Fade In/Out)
    private void applyAlphaAnimation() {
        // Create Alpha Animation programmatically
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(2000); // 2 seconds
        alphaAnimation.setStartOffset(500); // Start after 500ms
        alphaAnimation.setRepeatCount(2); // Repeat 2 times
        alphaAnimation.setRepeatMode(Animation.REVERSE); // Reverse animation
        alphaAnimation.setFillAfter(true); // Keep final state

        // Set animation listener
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Toast.makeText(MainActivity.this, "Alpha Animation Started", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Toast.makeText(MainActivity.this, "Alpha Animation Ended", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                Toast.makeText(MainActivity.this, "Alpha Animation Repeated", Toast.LENGTH_SHORT).show();
            }
        });

        textView.startAnimation(alphaAnimation);
    }

    // Method 2: Rotate Animation
    private void applyRotateAnimation() {
        // Create Rotate Animation programmatically
        RotateAnimation rotateAnimation = new RotateAnimation(
                0, 360, // from degrees, to degrees
                Animation.RELATIVE_TO_SELF, 0.5f, // pivot X
                Animation.RELATIVE_TO_SELF, 0.5f  // pivot Y
        );

        rotateAnimation.setDuration(2000);
        rotateAnimation.setRepeatCount(2);
        rotateAnimation.setRepeatMode(Animation.RESTART);
        rotateAnimation.setFillAfter(true);
        rotateAnimation.setStartOffset(500);

        textView.startAnimation(rotateAnimation);
    }

    // Method 3: Scale Animation
    private void applyScaleAnimation() {
        // Create Scale Animation programmatically
        ScaleAnimation scaleAnimation = new ScaleAnimation(
                1.0f, 2.0f, // from X scale, to X scale
                1.0f, 0.5f, // from Y scale, to Y scale
                Animation.RELATIVE_TO_SELF, 0.5f, // pivot X
                Animation.RELATIVE_TO_SELF, 0.5f  // pivot Y
        );

        scaleAnimation.setDuration(2000);
        scaleAnimation.setRepeatCount(1);
        scaleAnimation.setRepeatMode(Animation.REVERSE);
        scaleAnimation.setFillAfter(true);
        scaleAnimation.setInterpolator(this, android.R.anim.bounce_interpolator);

        textView.startAnimation(scaleAnimation);
    }

    // Method 4: Translate Animation
    private void applyTranslateAnimation() {
        // Create Translate Animation programmatically
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.5f
        );

        translateAnimation.setDuration(2500);
        translateAnimation.setRepeatCount(2);
        translateAnimation.setRepeatMode(Animation.REVERSE);
        translateAnimation.setFillAfter(true);
        translateAnimation.setStartOffset(1000);

        textView.startAnimation(translateAnimation);
    }

    // Method 5: Combined Animation using AnimationSet
    private void applyCombinedAnimation() {
        // Create Animation Set
        AnimationSet animationSet = new AnimationSet(true);

        // Alpha Animation
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.3f);
        alphaAnimation.setDuration(1500);

        // Rotate Animation
        RotateAnimation rotateAnimation = new RotateAnimation(
                0, 720,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        rotateAnimation.setDuration(1500);

        // Scale Animation
        ScaleAnimation scaleAnimation = new ScaleAnimation(
                1.0f, 1.5f,
                1.0f, 1.5f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        scaleAnimation.setDuration(1500);

        // Translate Animation
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 200.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 200.0f
        );
        translateAnimation.setDuration(1500);

        // Add animations to set
        animationSet.addAnimation(alphaAnimation);
        animationSet.addAnimation(rotateAnimation);
        animationSet.addAnimation(scaleAnimation);
        animationSet.addAnimation(translateAnimation);

        // Set properties for the set
        animationSet.setFillAfter(true);
        animationSet.setRepeatCount(1);
        animationSet.setRepeatMode(Animation.REVERSE);

        textView.startAnimation(animationSet);
    }

    // Alternative: Using XML animations
    private void loadAnimationFromXML() {
        // Load animation from XML file
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.custom_animation);
        textView.startAnimation(animation);
    }
}